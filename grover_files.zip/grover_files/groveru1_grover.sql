-- phpMyAdmin SQL Dump
-- version 4.9.11
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 04, 2024 at 05:31 AM
-- Server version: 10.3.39-MariaDB-log-cll-lve
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `groveru1_grover`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `position` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `name`, `position`, `email`, `phone`, `image`, `created_at`, `updated_at`) VALUES
(1, '{\"en\":\"Sherzod Shomuslimov\",\"uz\":\"Sherzod Shomuslimov\",\"ar\":\"\\u0634\\u064a\\u0631\\u0632\\u0648\\u062f \\u0634\\u0648\\u0645\\u0648\\u0633\\u0644\\u064a\\u0645\\u0648\\u0641\",\"ru\":\"\\u0428\\u0435\\u0440\\u0437\\u043e\\u0434 \\u0428\\u043e\\u043c\\u0443\\u0441\\u043b\\u0438\\u043c\\u043e\\u0432\"}', '{\"en\":\"Advisor\",\"uz\":\"Maslahatchi\",\"ar\":\"\\u0645\\u0633\\u062a\\u0634\\u0627\\u0631\",\"ru\":\"\\u0421\\u043e\\u0432\\u0435\\u0442\\u043d\\u0438\\u043a\"}', 'Shomuslimooov@gmail.com', '+998 94 421-44-12', 'hjIiHwOQWyopoSn6NQ9P88s8Ubw7XZZTDpSegR1u.png', '2024-03-28 13:13:27', '2024-03-29 10:18:09'),
(2, '{\"en\":\"Nurbek Ergashev\",\"ar\":\"\\u0646\\u0648\\u0631\\u0628\\u064a\\u0643 \\u0625\\u0631\\u062c\\u0627\\u0634\\u064a\\u0641\",\"ru\":\"\\u041d\\u0443\\u0440\\u0431\\u0435\\u043a \\u042d\\u0440\\u0433\\u0430\\u0448\\u0435\\u0432\",\"uz\":\"Nurbek Ergashev\"}', '{\"en\":\"CEO, Founder\",\"ar\":\"\\u0627\\u0644\\u0631\\u0626\\u064a\\u0633 \\u0627\\u0644\\u062a\\u0646\\u0641\\u064a\\u0630\\u064a\\u060c \\u0627\\u0644\\u0645\\u0624\\u0633\\u0633\",\"ru\":\"\\u0413\\u0435\\u043d\\u0435\\u0440\\u0430\\u043b\\u044c\\u043d\\u044b\\u0439 \\u0434\\u0438\\u0440\\u0435\\u043a\\u0442\\u043e\\u0440, \\u043e\\u0441\\u043d\\u043e\\u0432\\u0430\\u0442\\u0435\\u043b\\u044c\",\"uz\":\"Bosh direktor, ta\'sischi\"}', 'Alisher.hakimov@gmail.com', '+998 90 900-49-38', 't911YKxjKZ8sIQow8UUhpafMoCMuRV8rrwQJt0ox.png', '2024-03-28 13:13:27', '2024-03-29 10:17:44'),
(3, '{\"en\":\"Gulchehra Botirova\",\"ru\":\"\\u0413\\u0443\\u043b\\u0447\\u0435\\u0445\\u0440\\u0430 \\u0411\\u043e\\u0442\\u0438\\u0440\\u043e\\u0432\\u0430\",\"ar\":\"\\u062c\\u0648\\u0644\\u062a\\u0634\\u064a\\u0647\\u0631\\u0627 \\u0628\\u0648\\u062a\\u064a\\u0631\\u0648\\u0641\\u0627\",\"uz\":\"Gulchehra Botirova\"}', '{\"en\":\"HR director\",\"ar\":\"\\u0645\\u062f\\u064a\\u0631 \\u0627\\u0644\\u0645\\u0648\\u0627\\u0631\\u062f \\u0627\\u0644\\u0628\\u0634\\u0631\\u064a\\u0629\",\"ru\":\"HR \\u0434\\u0438\\u0440\\u0435\\u043a\\u0442\\u043e\\u0440\",\"uz\":\"HR direktor\"}', 'guli777@gmail.com', '+998 88 543-43-64', 'qlFO0bBjrBtK6zL5pVggV6dk2ISuXnx26XxHRONN.png', '2024-03-28 13:13:27', '2024-03-29 10:20:25'),
(10, '{\"en\":\"Akhmad Kadirov\",\"ru\":\"\\u0410\\u0445\\u043c\\u0430\\u0434 \\u041a\\u0430\\u0434\\u044b\\u0440\\u043e\\u0432\",\"uz\":\"Ahmad Qodirov\",\"ar\":\"\\u0623\\u062d\\u0645\\u062f \\u0642\\u062f\\u064a\\u0631\\u0648\\u0641\"}', '{\"en\":\"Copywriter\",\"ar\":\"\\u0645\\u0624\\u0644\\u0641 \\u0627\\u0644\\u0625\\u0639\\u0644\\u0627\\u0646\\u0627\\u062a\",\"uz\":\"Kopirayter\",\"ru\":\"\\u041a\\u043e\\u043f\\u0438\\u0440\\u0430\\u0439\\u0442\\u0435\\u0440\"}', 'akhmadk@grover.uz', '+998 94 421-44-12', 'xm7V4YbstQtfjeHLt7LzAkWiq22cbC9j5L01H52G.png', '2024-04-03 07:52:38', '2024-04-03 07:53:21');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2020_10_04_115514_create_moonshine_roles_table', 1),
(6, '2020_10_05_173148_create_moonshine_tables', 1),
(7, '2022_04_14_115549_create_moonshine_change_logs_table', 1),
(8, '2022_12_19_115549_create_moonshine_socialites_table', 1),
(9, '2023_01_20_173629_create_moonshine_user_permissions_table', 1),
(10, '2023_10_16_055344_create_testimonials_table', 1),
(11, '2023_10_16_075539_create_settings_table', 1),
(12, '2023_10_16_171743_create_members_table', 1),
(13, '2023_10_17_172957_create_vacations_table', 1),
(14, '2023_11_05_171026_create_projects_table', 1),
(15, '2023_11_06_072955_create_photos_table', 1),
(16, '9999_12_20_173629_create_notifications_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `moonshine_change_logs`
--

CREATE TABLE `moonshine_change_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `moonshine_user_id` bigint(20) UNSIGNED NOT NULL,
  `changelogable_type` varchar(255) NOT NULL,
  `changelogable_id` bigint(20) UNSIGNED NOT NULL,
  `states_before` longtext NOT NULL,
  `states_after` longtext NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `moonshine_socialites`
--

CREATE TABLE `moonshine_socialites` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `moonshine_user_id` bigint(20) UNSIGNED NOT NULL,
  `driver` varchar(255) NOT NULL,
  `identity` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `moonshine_users`
--

CREATE TABLE `moonshine_users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `moonshine_user_role_id` bigint(20) UNSIGNED NOT NULL DEFAULT 1,
  `email` varchar(190) NOT NULL,
  `password` varchar(60) NOT NULL,
  `name` varchar(255) NOT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `moonshine_users`
--

INSERT INTO `moonshine_users` (`id`, `moonshine_user_role_id`, `email`, `password`, `name`, `avatar`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 1, 'admin@grover.uz', '$2y$10$jcyjHHNQ1ytKeg3UEQGzXuud6edSlaX2CZPfCkestYTAxves.P/EG', 'Admin', NULL, 'iKHU1bU7lp0z6Os8FS0GEdTDZANOfk79H8Tj15TOCrlCNqyJo16KvYQ2dWhW', '2024-03-28 13:13:27', '2024-03-28 13:13:27');

-- --------------------------------------------------------

--
-- Table structure for table `moonshine_user_permissions`
--

CREATE TABLE `moonshine_user_permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `moonshine_user_id` bigint(20) UNSIGNED NOT NULL,
  `permissions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `moonshine_user_roles`
--

CREATE TABLE `moonshine_user_roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `moonshine_user_roles`
--

INSERT INTO `moonshine_user_roles` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Admin', '2024-03-28 13:13:27', '2024-03-28 13:13:27');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` char(36) NOT NULL,
  `type` varchar(255) NOT NULL,
  `notifiable_type` varchar(255) NOT NULL,
  `notifiable_id` bigint(20) UNSIGNED NOT NULL,
  `data` text NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

CREATE TABLE `photos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) NOT NULL,
  `project_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `photos`
--

INSERT INTO `photos` (`id`, `image`, `project_id`, `created_at`, `updated_at`) VALUES
(1, 'eco_sergeli_1.jpg', 1, '2024-03-28 13:13:27', '2024-03-28 13:13:27'),
(2, 'eco_sergeli_2.jpg', 1, '2024-03-28 13:13:27', '2024-03-28 13:13:27'),
(3, 'eco_sergeli_3.jpg', 1, '2024-03-28 13:13:27', '2024-03-28 13:13:27'),
(4, 'eco_sergeli_4.jpg', 1, '2024-03-28 13:13:27', '2024-03-28 13:13:27'),
(5, 'eco_sergeli_5.jpg', 1, '2024-03-28 13:13:27', '2024-03-28 13:13:27'),
(6, 'eco_sergeli_6.jpg', 1, '2024-03-28 13:13:27', '2024-03-28 13:13:27');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `finished_at` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `title`, `slug`, `description`, `finished_at`, `created_at`, `updated_at`) VALUES
(1, 'Eco Sergeli', 'eco-sergeli', '{\"en\":\"<p>1) 166 Residential Units<br>2) 32 Commercial Units<br>3) It was launched in 2019 and finished in 2021&nbsp;<br>4) The entire project was entirely sold out within its first year of launch.&nbsp;<br>5) Project was timely and successfuly deliverd to the owners.<\\/p>\",\"ru\":\"<p>1. 166 \\u0440\\u0435\\u0437\\u0438\\u0434\\u0435\\u043d\\u0446\\u0438\\u0439.<br>2. 32 \\u0436\\u0438\\u043b\\u044b\\u0445 \\u043c\\u0430\\u0441\\u0441\\u0438\\u0432\\u0430.<br>3. 2019 \\u0433\\u043e\\u0434 \\u043d\\u0430\\u0447\\u0430\\u043b\\u0441\\u044f \\u0438 2021 \\u0433\\u043e\\u0434 \\u0437\\u0430\\u043a\\u043e\\u043d\\u0447\\u0438\\u043b\\u0441\\u044f.<br>4. \\u041f\\u043e\\u043a\\u0443\\u043f\\u043a\\u0430 \\u0441\\u043e\\u0432\\u0435\\u0440\\u0448\\u0435\\u043d\\u0430 \\u0432 \\u0442\\u0435\\u0447\\u0435\\u043d\\u0438\\u0435 1 \\u0433\\u043e\\u0434\\u0430.<br>5. 100% \\u043f\\u0440\\u043e\\u0434\\u0430\\u043d\\u043e \\u0434\\u043e \\u0437\\u0430\\u0432\\u0435\\u0440\\u0448\\u0435\\u043d\\u0438\\u044f.<\\/p>\",\"ar\":\"<p>1.166 \\u0633\\u0643\\u0646\\u064a\\u0629.<br>2. 32 \\u00d7 \\u0635\\u0641\\u064a\\u0641.<br>3. \\u0633\\u064a\\u062a\\u0645 \\u0625\\u0637\\u0644\\u0627\\u0642\\u0647 \\u0641\\u064a \\u0639\\u0627\\u0645 2019 \\u0648\\u0627\\u0644\\u0627\\u0646\\u062a\\u0647\\u0627\\u0621 \\u0645\\u0646\\u0647 \\u0641\\u064a \\u0639\\u0627\\u0645 2021.<br>4. \\u0642\\u0645 \\u0628\\u0634\\u0631\\u0627\\u0621 \\u0644\\u0645\\u062f\\u0629 \\u0639\\u0627\\u0645 \\u0648\\u0627\\u062d\\u062f.<br>5. 100% \\u0645\\u0635\\u0646\\u0648\\u0639 \\u0645\\u0646 \\u0645\\u0648\\u0627\\u062f \\u0635\\u0646\\u0627\\u0639\\u064a\\u0629.<\\/p>\",\"uz\":\"<p>1. 166 ta turar joy.<br>2. 32 ta noturar joy.<br>3. 2019-yil boshlanib, 2021-yil tugagan.<br>4. 1 yil mobaynida sotib tugatilgan.<br>5. Qurib bitmasidan oldin 100% sotilgan.<\\/p>\"}', '2021-02-01', '2024-03-28 13:13:27', '2024-04-02 23:14:33'),
(2, 'Eco Capital Stroy', 'eco-capital-stroy', '{\"en\":\"<p>1) 166 Residential Units<br>2) 32 Commercial Units<br>3) It was launched in 2019 and finished in 2021&nbsp;<br>4) The entire project was entirely sold out within its first year of launch.&nbsp;<br>5) Project was timely and successfuly deliverd to the owners.<\\/p>\",\"ru\":\"<p>1. 166 \\u0440\\u0435\\u0437\\u0438\\u0434\\u0435\\u043d\\u0446\\u0438\\u0439.<br>2. 32 \\u0436\\u0438\\u043b\\u044b\\u0445 \\u043c\\u0430\\u0441\\u0441\\u0438\\u0432\\u0430.<br>3. 2019 \\u0433\\u043e\\u0434 \\u043d\\u0430\\u0447\\u0430\\u043b\\u0441\\u044f \\u0438 2021 \\u0433\\u043e\\u0434 \\u0437\\u0430\\u043a\\u043e\\u043d\\u0447\\u0438\\u043b\\u0441\\u044f.<br>4. \\u041f\\u043e\\u043a\\u0443\\u043f\\u043a\\u0430 \\u0441\\u043e\\u0432\\u0435\\u0440\\u0448\\u0435\\u043d\\u0430 \\u0432 \\u0442\\u0435\\u0447\\u0435\\u043d\\u0438\\u0435 1 \\u0433\\u043e\\u0434\\u0430.<br>5. 100% \\u043f\\u0440\\u043e\\u0434\\u0430\\u043d\\u043e \\u0434\\u043e \\u0437\\u0430\\u0432\\u0435\\u0440\\u0448\\u0435\\u043d\\u0438\\u044f.<\\/p>\",\"uz\":\"<p>1. 166 ta turar joy.<br>2. 32 ta noturar joy.<br>3. 2019-yil boshlanib, 2021-yil tugagan.<br>4. 1 yil mobaynida sotib tugatilgan.<br>5. Qurib bitmasidan oldin 100% sotilgan.<\\/p>\",\"ar\":\"<p>1.166 \\u0633\\u0643\\u0646\\u064a\\u0629.<br>2. 32 \\u00d7 \\u0635\\u0641\\u064a\\u0641.<br>3. \\u0633\\u064a\\u062a\\u0645 \\u0625\\u0637\\u0644\\u0627\\u0642\\u0647 \\u0641\\u064a \\u0639\\u0627\\u0645 2019 \\u0648\\u0627\\u0644\\u0627\\u0646\\u062a\\u0647\\u0627\\u0621 \\u0645\\u0646\\u0647 \\u0641\\u064a \\u0639\\u0627\\u0645 2021.<br>4. \\u0642\\u0645 \\u0628\\u0634\\u0631\\u0627\\u0621 \\u0644\\u0645\\u062f\\u0629 \\u0639\\u0627\\u0645 \\u0648\\u0627\\u062d\\u062f.<br>5. 100% \\u0645\\u0635\\u0646\\u0648\\u0639 \\u0645\\u0646 \\u0645\\u0648\\u0627\\u062f \\u0635\\u0646\\u0627\\u0639\\u064a\\u0629.<\\/p>\"}', '2017-07-14', '2024-03-28 13:13:27', '2024-04-02 23:14:43'),
(3, 'Dara Elite', 'dara-elite', '{\"en\":\"<p>1) 166 Residential Units<br>2) 32 Commercial Units<br>3) It was launched in 2019 and finished in 2021&nbsp;<br>4) The entire project was entirely sold out within its first year of launch.&nbsp;<br>5) Project was timely and successfuly deliverd to the owners.<\\/p>\",\"ru\":\"<p>1. 166 \\u0440\\u0435\\u0437\\u0438\\u0434\\u0435\\u043d\\u0446\\u0438\\u0439.<br>2. 32 \\u0436\\u0438\\u043b\\u044b\\u0445 \\u043c\\u0430\\u0441\\u0441\\u0438\\u0432\\u0430.<br>3. 2019 \\u0433\\u043e\\u0434 \\u043d\\u0430\\u0447\\u0430\\u043b\\u0441\\u044f \\u0438 2021 \\u0433\\u043e\\u0434 \\u0437\\u0430\\u043a\\u043e\\u043d\\u0447\\u0438\\u043b\\u0441\\u044f.<br>4. \\u041f\\u043e\\u043a\\u0443\\u043f\\u043a\\u0430 \\u0441\\u043e\\u0432\\u0435\\u0440\\u0448\\u0435\\u043d\\u0430 \\u0432 \\u0442\\u0435\\u0447\\u0435\\u043d\\u0438\\u0435 1 \\u0433\\u043e\\u0434\\u0430.<br>5. 100% \\u043f\\u0440\\u043e\\u0434\\u0430\\u043d\\u043e \\u0434\\u043e \\u0437\\u0430\\u0432\\u0435\\u0440\\u0448\\u0435\\u043d\\u0438\\u044f.<\\/p>\",\"uz\":\"<p>1. 166 ta turar joy.<br>2. 32 ta noturar joy.<br>3. 2019-yil boshlanib, 2021-yil tugagan.<br>4. 1 yil mobaynida sotib tugatilgan.<br>5. Qurib bitmasidan oldin 100% sotilgan.<\\/p>\",\"ar\":\"<p>1.166 \\u0633\\u0643\\u0646\\u064a\\u0629.<br>2. 32 \\u00d7 \\u0635\\u0641\\u064a\\u0641.<br>3. \\u0633\\u064a\\u062a\\u0645 \\u0625\\u0637\\u0644\\u0627\\u0642\\u0647 \\u0641\\u064a \\u0639\\u0627\\u0645 2019 \\u0648\\u0627\\u0644\\u0627\\u0646\\u062a\\u0647\\u0627\\u0621 \\u0645\\u0646\\u0647 \\u0641\\u064a \\u0639\\u0627\\u0645 2021.<br>4. \\u0642\\u0645 \\u0628\\u0634\\u0631\\u0627\\u0621 \\u0644\\u0645\\u062f\\u0629 \\u0639\\u0627\\u0645 \\u0648\\u0627\\u062d\\u062f.<br>5. 100% \\u0645\\u0635\\u0646\\u0648\\u0639 \\u0645\\u0646 \\u0645\\u0648\\u0627\\u062f \\u0635\\u0646\\u0627\\u0639\\u064a\\u0629.<\\/p>\"}', '2021-06-15', '2024-03-28 13:13:27', '2024-04-02 23:14:50'),
(4, 'Muhtasham', 'muhtasham', '{\"en\":\"<p>1) 166 Residential Units<br>2) 32 Commercial Units<br>3) It was launched in 2019 and finished in 2021&nbsp;<br>4) The entire project was entirely sold out within its first year of launch.&nbsp;<br>5) Project was timely and successfuly deliverd to the owners.<\\/p>\",\"ru\":\"<p>1. 166 \\u0440\\u0435\\u0437\\u0438\\u0434\\u0435\\u043d\\u0446\\u0438\\u0439.<br>2. 32 \\u0436\\u0438\\u043b\\u044b\\u0445 \\u043c\\u0430\\u0441\\u0441\\u0438\\u0432\\u0430.<br>3. 2019 \\u0433\\u043e\\u0434 \\u043d\\u0430\\u0447\\u0430\\u043b\\u0441\\u044f \\u0438 2021 \\u0433\\u043e\\u0434 \\u0437\\u0430\\u043a\\u043e\\u043d\\u0447\\u0438\\u043b\\u0441\\u044f.<br>4. \\u041f\\u043e\\u043a\\u0443\\u043f\\u043a\\u0430 \\u0441\\u043e\\u0432\\u0435\\u0440\\u0448\\u0435\\u043d\\u0430 \\u0432 \\u0442\\u0435\\u0447\\u0435\\u043d\\u0438\\u0435 1 \\u0433\\u043e\\u0434\\u0430.<br>5. 100% \\u043f\\u0440\\u043e\\u0434\\u0430\\u043d\\u043e \\u0434\\u043e \\u0437\\u0430\\u0432\\u0435\\u0440\\u0448\\u0435\\u043d\\u0438\\u044f.<\\/p>\",\"uz\":\"<p>1. 166 ta turar joy.<br>2. 32 ta noturar joy.<br>3. 2019-yil boshlanib, 2021-yil tugagan.<br>4. 1 yil mobaynida sotib tugatilgan.<br>5. Qurib bitmasidan oldin 100% sotilgan.<\\/p>\",\"ar\":\"<p>1.166 \\u0633\\u0643\\u0646\\u064a\\u0629.<br>2. 32 \\u00d7 \\u0635\\u0641\\u064a\\u0641.<br>3. \\u0633\\u064a\\u062a\\u0645 \\u0625\\u0637\\u0644\\u0627\\u0642\\u0647 \\u0641\\u064a \\u0639\\u0627\\u0645 2019 \\u0648\\u0627\\u0644\\u0627\\u0646\\u062a\\u0647\\u0627\\u0621 \\u0645\\u0646\\u0647 \\u0641\\u064a \\u0639\\u0627\\u0645 2021.<br>4. \\u0642\\u0645 \\u0628\\u0634\\u0631\\u0627\\u0621 \\u0644\\u0645\\u062f\\u0629 \\u0639\\u0627\\u0645 \\u0648\\u0627\\u062d\\u062f.<br>5. 100% \\u0645\\u0635\\u0646\\u0648\\u0639 \\u0645\\u0646 \\u0645\\u0648\\u0627\\u062f \\u0635\\u0646\\u0627\\u0639\\u064a\\u0629.<\\/p>\"}', '2021-10-12', '2024-03-28 13:13:27', '2024-04-02 23:14:56');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `url` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `key`, `value`, `url`, `created_at`, `updated_at`) VALUES
(1, 'telegram', NULL, '#', '2024-03-28 13:13:27', '2024-03-28 13:13:27'),
(2, 'youtube', NULL, '#', '2024-03-28 13:13:27', '2024-03-28 13:13:27'),
(3, 'instagram', NULL, '#', '2024-03-28 13:13:27', '2024-03-28 13:13:27'),
(4, 'facebook', NULL, '#', '2024-03-28 13:13:27', '2024-03-28 13:13:27'),
(5, 'twitter', NULL, '#', '2024-03-28 13:13:27', '2024-03-28 13:13:27'),
(6, 'map', NULL, 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6002.513750409236!2d69.23761184257856!3d41.216172295349395!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x38ae60fcf2af0dcd%3A0x72d45eb7de954541!2z0JzQsNGB0YHQuNCyINCh0LXRgNCz0LXQu9C4LCDQmtCy0LDRgNGC0LDQuyA0!5e0!3m2!1sru!2s!4v1697472759031!5m2!1sru!2s', '2024-03-28 13:13:27', '2024-03-28 13:13:27'),
(7, 'city', '{\"en\":\"Tashkent\",\"ar\":\"\\u0637\\u0634\\u0642\\u0646\\u062f\",\"ru\":\"\\u0422\\u0430\\u0448\\u043a\\u0435\\u043d\\u0442\",\"uz\":\"Toshkent\"}', NULL, '2024-03-28 13:13:27', '2024-03-29 10:24:28'),
(8, 'address', '{\"en\":\"48, Sergeli-4, Tashkent\",\"ar\":\"48\\u060c \\u0633\\u064a\\u0631\\u062c\\u064a\\u0644\\u064a -4\\u060c \\u0637\\u0634\\u0642\\u0646\\u062f\",\"ru\":\"\\u0433. \\u0422\\u0430\\u0448\\u043a\\u0435\\u043d\\u0442, \\u0421\\u0435\\u0440\\u0433\\u0435\\u043b\\u0438-4, 48\",\"uz\":\"Toshkent sh., Sergeli-4, 48-uy\"}', NULL, '2024-03-28 13:13:27', '2024-03-29 10:23:08'),
(9, 'phone', NULL, '+998 90 900-49-38', '2024-03-28 13:13:27', '2024-03-28 13:13:27'),
(10, 'email', NULL, 'grover.tashkent@info.uz', '2024-03-28 13:13:27', '2024-03-28 13:13:27'),
(11, 'city', '{\"en\":\"Andijan\",\"ru\":\"\\u0410\\u043d\\u0434\\u0438\\u0436\\u0430\\u043d\",\"ar\":\"\\u0623\\u0646\\u062f\\u064a\\u062c\\u0648\\u0646\",\"uz\":\"Andijon\"}', NULL, '2024-03-28 13:13:27', '2024-03-29 10:23:54'),
(12, 'address', '{\"en\":\"3, A. Temur street, Andijan\",\"ar\":\"3\\u060c \\u0634\\u0627\\u0631\\u0639 \\u0623. \\u062a\\u064a\\u0645\\u0648\\u0631\\u060c \\u0623\\u0646\\u062f\\u064a\\u062c\\u0627\\u0646\",\"ru\":\"\\u0433. \\u0410\\u043d\\u0434\\u0438\\u0436\\u0430\\u043d, \\u0443\\u043b\\u0438\\u0446\\u0430 \\u0410. \\u0422\\u0438\\u043c\\u0443\\u0440\\u0430, 3\",\"uz\":\"Andijon shahri, A. Temur ko\\u2018chasi, 3-uy\"}', NULL, '2024-03-28 13:13:27', '2024-03-29 10:22:04'),
(13, 'phone', NULL, '+998 71 210-45-15', '2024-03-28 13:13:27', '2024-03-28 13:13:27'),
(14, 'email', NULL, 'grover.andijan@info.uz', '2024-03-28 13:13:27', '2024-03-28 13:13:27');

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `author` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `text` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `author`, `text`, `created_at`, `updated_at`) VALUES
(1, '{\"en\":\"Khikmat Salyamov\",\"ar\":\"\\u062d\\u0643\\u0645\\u062a \\u0633\\u0627\\u0644\\u064a\\u0627\\u0645\\u0648\\u0641\",\"ru\":\"\\u0425\\u0438\\u043a\\u043c\\u0430\\u0442 \\u0421\\u0430\\u043b\\u044f\\u043c\\u043e\\u0432\",\"uz\":\"Hikmat Salyamov\"}', '{\"en\":\"<p>Grover has truly been a game-changer for our project. Their dedication to excellence, professionalism, and expertise in the field have exceeded our expectations. From start to finish, they demonstrated unparalleled commitment and skill, ensuring that every aspect of our construction needs was met with precision and efficiency. Grover\'s team not only delivered top-notch results but also offered invaluable insights and solutions throughout the process.<\\/p>\",\"ar\":\"<p>\\u0644\\u0642\\u062f \\u063a\\u064a\\u0631\\u062a \\u0634\\u0631\\u0643\\u0629 Grover &nbsp;\\u0642\\u0648\\u0627\\u0639\\u062f \\u0627\\u0644\\u0644\\u0639\\u0628\\u0629 \\u0644\\u0645\\u0634\\u0631\\u0648\\u0639\\u0646\\u0627 \\u062d\\u0642\\u064b\\u0627. \\u0644\\u0642\\u062f \\u062a\\u062c\\u0627\\u0648\\u0632 \\u062a\\u0641\\u0627\\u0646\\u064a\\u0647\\u0645 \\u0641\\u064a \\u0627\\u0644\\u062a\\u0645\\u064a\\u0632 \\u0648\\u0627\\u0644\\u0643\\u0641\\u0627\\u0621\\u0629 \\u0627\\u0644\\u0645\\u0647\\u0646\\u064a\\u0629 \\u0648\\u0627\\u0644\\u062e\\u0628\\u0631\\u0629 \\u0641\\u064a \\u0647\\u0630\\u0627 \\u0627\\u0644\\u0645\\u062c\\u0627\\u0644 \\u062a\\u0648\\u0642\\u0639\\u0627\\u062a\\u0646\\u0627. \\u0645\\u0646 \\u0627\\u0644\\u0628\\u062f\\u0627\\u064a\\u0629 \\u0625\\u0644\\u0649 \\u0627\\u0644\\u0646\\u0647\\u0627\\u064a\\u0629\\u060c \\u0623\\u0638\\u0647\\u0631\\u0648\\u0627 \\u0627\\u0644\\u062a\\u0632\\u0627\\u0645\\u064b\\u0627 \\u0648\\u0645\\u0647\\u0627\\u0631\\u0629 \\u0644\\u0627 \\u0645\\u062b\\u064a\\u0644 \\u0644\\u0647\\u0645\\u0627\\u060c \\u0645\\u0645\\u0627 \\u064a\\u0636\\u0645\\u0646 \\u062a\\u0644\\u0628\\u064a\\u0629 \\u0643\\u0644 \\u062c\\u0627\\u0646\\u0628 \\u0645\\u0646 \\u062c\\u0648\\u0627\\u0646\\u0628 \\u0627\\u062d\\u062a\\u064a\\u0627\\u062c\\u0627\\u062a \\u0627\\u0644\\u0628\\u0646\\u0627\\u0621 \\u0644\\u062f\\u064a\\u0646\\u0627 \\u0628\\u062f\\u0642\\u0629 \\u0648\\u0643\\u0641\\u0627\\u0621\\u0629. \\u0644\\u0645 \\u064a\\u062d\\u0642\\u0642 \\u0641\\u0631\\u064a\\u0642 Grover \\u0646\\u062a\\u0627\\u0626\\u062c \\u0631\\u0641\\u064a\\u0639\\u0629 \\u0644\\u0639\\u0645\\u0644\\u064a\\u0629. \\u0644\\u0642\\u062f \\u0643\\u0627\\u0646 \\u0627\\u0644\\u0639\\u0645\\u0644 \\u0645\\u0639\\u0647\\u0645 \\u0645\\u062a\\u0639\\u0629 \\u0645\\u0637\\u0644\\u0642\\u0629\\u060c \\u0648\\u0646\\u062d\\u0646 \\u0646\\u0648\\u0635\\u064a \\u0628\\u0634\\u062f.<\\/p>\",\"ru\":\"<p>Grover \\u0434\\u0435\\u0439\\u0441\\u0442\\u0432\\u0438\\u0442\\u0435\\u043b\\u044c\\u043d\\u043e \\u0438\\u0437\\u043c\\u0435\\u043d\\u0438\\u043b \\u043f\\u0440\\u0430\\u0432\\u0438\\u043b\\u0430 \\u0438\\u0433\\u0440\\u044b \\u0432 \\u043d\\u0430\\u0448\\u0435\\u043c \\u043f\\u0440\\u043e\\u0435\\u043a\\u0442\\u0435. \\u0418\\u0445 \\u0441\\u0442\\u0440\\u0435\\u043c\\u043b\\u0435\\u043d\\u0438\\u0435 \\u043a \\u0441\\u043e\\u0432\\u0435\\u0440\\u0448\\u0435\\u043d\\u0441\\u0442\\u0432\\u0443, \\u043f\\u0440\\u043e\\u0444\\u0435\\u0441\\u0441\\u0438\\u043e\\u043d\\u0430\\u043b\\u0438\\u0437\\u043c \\u0438 \\u043e\\u043f\\u044b\\u0442 \\u0432 \\u044d\\u0442\\u043e\\u0439 \\u043e\\u0431\\u043b\\u0430\\u0441\\u0442\\u0438 \\u043f\\u0440\\u0435\\u0432\\u0437\\u043e\\u0448\\u043b\\u0438 \\u043d\\u0430\\u0448\\u0438 \\u043e\\u0436\\u0438\\u0434\\u0430\\u043d\\u0438\\u044f. \\u041e\\u0442 \\u043d\\u0430\\u0447\\u0430\\u043b\\u0430 \\u0434\\u043e \\u043a\\u043e\\u043d\\u0446\\u0430 \\u043e\\u043d\\u0438 \\u043f\\u0440\\u043e\\u0434\\u0435\\u043c\\u043e\\u043d\\u0441\\u0442\\u0440\\u0438\\u0440\\u043e\\u0432\\u0430\\u043b\\u0438 \\u0431\\u0435\\u0441\\u043f\\u0440\\u0435\\u0446\\u0435\\u0434\\u0435\\u043d\\u0442\\u043d\\u0443\\u044e \\u043f\\u0440\\u0438\\u0432\\u0435\\u0440\\u0436\\u0435\\u043d\\u043d\\u043e\\u0441\\u0442\\u044c \\u0438 \\u043c\\u0430\\u0441\\u0442\\u0435\\u0440\\u0441\\u0442\\u0432\\u043e, \\u0433\\u0430\\u0440\\u0430\\u043d\\u0442\\u0438\\u0440\\u0443\\u044f, \\u0447\\u0442\\u043e \\u043a\\u0430\\u0436\\u0434\\u044b\\u0439 \\u0430\\u0441\\u043f\\u0435\\u043a\\u0442 \\u043d\\u0430\\u0448\\u0438\\u0445 \\u0441\\u0442\\u0440\\u043e\\u0438\\u0442\\u0435\\u043b\\u044c\\u043d\\u044b\\u0445 \\u043f\\u043e\\u0442\\u0440\\u0435\\u0431\\u043d\\u043e\\u0441\\u0442\\u0435\\u0439 \\u0431\\u0443\\u0434\\u0435\\u0442 \\u0432\\u044b\\u043f\\u043e\\u043b\\u043d\\u0435\\u043d \\u0441 \\u0442\\u043e\\u0447\\u043d\\u043e\\u0441\\u0442\\u044c\\u044e \\u0438 \\u044d\\u0444\\u0444\\u0435\\u043a\\u0442\\u0438\\u0432\\u043d\\u043e\\u0441\\u0442\\u044c\\u044e. \\u041a\\u043e\\u043c\\u0430\\u043d\\u0434\\u0430 Grover \\u043d\\u0435 \\u0442\\u043e\\u043b\\u044c\\u043a\\u043e \\u0434\\u043e\\u0431\\u0438\\u043b\\u0430\\u0441\\u044c \\u043f\\u0435\\u0440\\u0432\\u043e\\u043a\\u043b\\u0430\\u0441\\u0441\\u043d\\u044b\\u0445 \\u0440\\u0435\\u0437\\u0443\\u043b\\u044c\\u0442\\u0430\\u0442\\u043e\\u0432, \\u043d\\u043e \\u0438 \\u043f\\u0440\\u0435\\u0434\\u043b\\u043e\\u0436\\u0438\\u043b\\u0430 \\u0431\\u0435\\u0441\\u0446\\u0435\\u043d\\u043d\\u044b\\u0435 \\u0438\\u0434\\u0435\\u0438 \\u0438 \\u0440\\u0435\\u0448\\u0435\\u043d\\u0438\\u044f \\u043d\\u0430 \\u043f\\u0440\\u043e\\u0442\\u044f\\u0436\\u0435\\u043d\\u0438\\u0438 \\u0432\\u0441\\u0435\\u0433\\u043e \\u043f\\u0440\\u043e\\u0446\\u0435\\u0441\\u0441\\u0430.<\\/p>\",\"uz\":\"<p>Grover haqiqatan ham loyihamiz uchun o\'yinni o\'zgartiruvchi bo\'ldi. Ularning mukammallikka sodiqligi, professionalligi va sohadagi tajribasi kutganimizdan ham oshib ketdi. Ular boshidan oxirigacha qurilish ehtiyojlarining har bir jihati aniqlik va samaradorlik bilan qondirilishini ta\'minlab, misli ko\'rilmagan sodiqlik va mahoratni namoyish etdi. Grover jamoasi nafaqat yuqori darajadagi natijalarni taqdim etdi, balki butun jarayon davomida bebaho tushunchalar va echimlarni taklif qildi.<\\/p>\"}', '2024-03-28 13:13:27', '2024-03-29 10:45:14'),
(2, '{\"en\":\"Ahmad Sobirov\",\"uz\":\"Ahmad Sobirov\",\"ru\":\"\\u0410\\u0445\\u043c\\u0430\\u0434 \\u0421\\u043e\\u0431\\u0438\\u0440\\u043e\\u0432\",\"ar\":\"\\u0623\\u062d\\u0645\\u062f \\u0633\\u0648\\u0628\\u064a\\u0631\\u0648\\u0641\"}', '{\"en\":\"<p>Choosing Grover for our construction, distribution, and import-export needs was one of the best decisions we made for our business. Their comprehensive range of services streamlined our operations and enhanced our efficiency significantly. Whether it was constructing a new facility, managing distribution channels, or handling import-export logistics, Grover\'s expertise and professionalism shone through at every step.<\\/p>\",\"ru\":\"<p>\\u0412\\u044b\\u0431\\u043e\\u0440 \\u043a\\u043e\\u043c\\u043f\\u0430\\u043d\\u0438\\u0438 Grover \\u0434\\u043b\\u044f \\u043d\\u0443\\u0436\\u0434 \\u0441\\u0442\\u0440\\u043e\\u0438\\u0442\\u0435\\u043b\\u044c\\u0441\\u0442\\u0432\\u0430, \\u0434\\u0438\\u0441\\u0442\\u0440\\u0438\\u0431\\u0443\\u0446\\u0438\\u0438 \\u0438 \\u0438\\u043c\\u043f\\u043e\\u0440\\u0442\\u0430-\\u044d\\u043a\\u0441\\u043f\\u043e\\u0440\\u0442\\u0430 \\u0431\\u044b\\u043b \\u043e\\u0434\\u043d\\u0438\\u043c \\u0438\\u0437 \\u043b\\u0443\\u0447\\u0448\\u0438\\u0445 \\u0440\\u0435\\u0448\\u0435\\u043d\\u0438\\u0439, \\u043a\\u043e\\u0442\\u043e\\u0440\\u044b\\u0435 \\u043c\\u044b \\u043f\\u0440\\u0438\\u043d\\u044f\\u043b\\u0438 \\u0434\\u043b\\u044f \\u043d\\u0430\\u0448\\u0435\\u0433\\u043e \\u0431\\u0438\\u0437\\u043d\\u0435\\u0441\\u0430. \\u0418\\u0445 \\u0448\\u0438\\u0440\\u043e\\u043a\\u0438\\u0439 \\u0441\\u043f\\u0435\\u043a\\u0442\\u0440 \\u0443\\u0441\\u043b\\u0443\\u0433 \\u043e\\u043f\\u0442\\u0438\\u043c\\u0438\\u0437\\u0438\\u0440\\u043e\\u0432\\u0430\\u043b \\u043d\\u0430\\u0448\\u0443 \\u0434\\u0435\\u044f\\u0442\\u0435\\u043b\\u044c\\u043d\\u043e\\u0441\\u0442\\u044c \\u0438 \\u0437\\u043d\\u0430\\u0447\\u0438\\u0442\\u0435\\u043b\\u044c\\u043d\\u043e \\u043f\\u043e\\u0432\\u044b\\u0441\\u0438\\u043b \\u0435\\u0435 \\u044d\\u0444\\u0444\\u0435\\u043a\\u0442\\u0438\\u0432\\u043d\\u043e\\u0441\\u0442\\u044c. \\u0411\\u0443\\u0434\\u044c \\u0442\\u043e \\u0441\\u0442\\u0440\\u043e\\u0438\\u0442\\u0435\\u043b\\u044c\\u0441\\u0442\\u0432\\u043e \\u043d\\u043e\\u0432\\u043e\\u0433\\u043e \\u043e\\u0431\\u044a\\u0435\\u043a\\u0442\\u0430, \\u0443\\u043f\\u0440\\u0430\\u0432\\u043b\\u0435\\u043d\\u0438\\u0435 \\u043a\\u0430\\u043d\\u0430\\u043b\\u0430\\u043c\\u0438 \\u0441\\u0431\\u044b\\u0442\\u0430 \\u0438\\u043b\\u0438 \\u043e\\u0440\\u0433\\u0430\\u043d\\u0438\\u0437\\u0430\\u0446\\u0438\\u044f \\u0438\\u043c\\u043f\\u043e\\u0440\\u0442\\u043d\\u043e-\\u044d\\u043a\\u0441\\u043f\\u043e\\u0440\\u0442\\u043d\\u043e\\u0439 \\u043b\\u043e\\u0433\\u0438\\u0441\\u0442\\u0438\\u043a\\u0438, \\u043e\\u043f\\u044b\\u0442 \\u0438 \\u043f\\u0440\\u043e\\u0444\\u0435\\u0441\\u0441\\u0438\\u043e\\u043d\\u0430\\u043b\\u0438\\u0437\\u043c \\u0413\\u0440\\u043e\\u0432\\u0435\\u0440\\u0430 \\u043f\\u0440\\u043e\\u044f\\u0432\\u043b\\u044f\\u043b\\u0438\\u0441\\u044c \\u043d\\u0430 \\u043a\\u0430\\u0436\\u0434\\u043e\\u043c \\u044d\\u0442\\u0430\\u043f\\u0435.<\\/p>\",\"uz\":\"<p>Qurilish, tarqatish va import-eksport ehtiyojlarimiz uchun Groverni tanlash biznesimiz uchun qabul qilgan eng yaxshi qarorlardan biri edi. Ularning keng qamrovli xizmatlari bizning faoliyatimizni soddalashtirdi va samaradorligimizni sezilarli darajada oshirdi. Yangi ob\'ektni qurish, tarqatish kanallarini boshqarish yoki import-eksport logistikasini boshqarish bo\'ladimi, Groverning tajribasi va professionalligi har qadamda yorqin namoyon bo\'ldi.<\\/p>\",\"ar\":\"<p>\\u0643\\u0627\\u0646 \\u0627\\u062e\\u062a\\u064a\\u0627\\u0631 Grover \\u0644\\u062a\\u0644\\u0628\\u064a\\u0629 \\u0627\\u062d\\u062a\\u064a\\u0627\\u062c\\u0627\\u062a \\u0627\\u0644\\u0628\\u0646\\u0627\\u0621 \\u0648\\u0627\\u0644\\u062a\\u0648\\u0632\\u064a\\u0639 \\u0648\\u0627\\u0644\\u0627\\u0633\\u062a\\u064a\\u0631\\u0627\\u062f \\u0648\\u0627\\u0644\\u062a\\u0635\\u062f\\u064a\\u0631 \\u0623\\u062d\\u062f \\u0623\\u0641\\u0636\\u0644 \\u0627\\u0644\\u0642\\u0631\\u0627\\u0631\\u0627\\u062a \\u0627\\u0644\\u062a\\u064a \\u0627\\u062a\\u062e\\u0630\\u0646\\u0627\\u0647\\u0627 \\u0644\\u0623\\u0639\\u0645\\u0627\\u0644\\u0646\\u0627. \\u0648\\u0642\\u062f \\u0623\\u062f\\u062a \\u0645\\u062c\\u0645\\u0648\\u0639\\u0629 \\u0627\\u0644\\u062e\\u062f\\u0645\\u0627\\u062a \\u0627\\u0644\\u0634\\u0627\\u0645\\u0644\\u0629 \\u0627\\u0644\\u062a\\u064a \\u064a\\u0642\\u062f\\u0645\\u0648\\u0646\\u0647\\u0627 \\u0625\\u0644\\u0649 \\u062a\\u0628\\u0633\\u064a\\u0637 \\u0639\\u0645\\u0644\\u064a\\u0627\\u062a\\u0646\\u0627 \\u0648\\u062a\\u0639\\u0632\\u064a\\u0632 \\u0643\\u0641\\u0627\\u0621\\u062a\\u0646\\u0627 \\u0628\\u0634\\u0643\\u0644 \\u0643\\u0628\\u064a\\u0631. \\u0633\\u0648\\u0627\\u0621 \\u0643\\u0627\\u0646 \\u0627\\u0644\\u0623\\u0645\\u0631 \\u064a\\u062a\\u0639\\u0644\\u0642 \\u0628\\u0628\\u0646\\u0627\\u0621 \\u0645\\u0646\\u0634\\u0623\\u0629 \\u062c\\u062f\\u064a\\u062f\\u0629\\u060c \\u0623\\u0648 \\u0625\\u062f\\u0627\\u0631\\u0629 \\u0642\\u0646\\u0648\\u0627\\u062a \\u0627\\u0644\\u062a\\u0648\\u0632\\u064a\\u0639\\u060c \\u0623\\u0648 \\u0627\\u0644\\u062a\\u0639\\u0627\\u0645\\u0644 \\u0645\\u0639 \\u0644\\u0648\\u062c\\u0633\\u062a\\u064a\\u0627\\u062a \\u0627\\u0644\\u0627\\u0633\\u062a\\u064a\\u0631\\u0627\\u062f \\u0648\\u0627\\u0644\\u062a\\u0635\\u062f\\u064a\\u0631\\u060c \\u0641\\u0642\\u062f \\u0628\\u0631\\u0632\\u062a \\u062e\\u0628\\u0631\\u0629 \\u062c\\u0631\\u0648\\u0641\\u0631 \\u0648\\u0627\\u062d\\u062a\\u0631\\u0627\\u0641\\u064a\\u062a\\u0647 \\u0641\\u064a \\u0643\\u0644 \\u062e\\u0637\\u0648\\u0629.<\\/p>\"}', '2024-03-28 13:13:27', '2024-03-29 10:41:33'),
(3, '{\"en\":\"Sarvar Kamolov\",\"uz\":\"Sarvar Kamolov\",\"ru\":\"\\u0421\\u0430\\u0440\\u0432\\u0430\\u0440 \\u041a\\u0430\\u043c\\u043e\\u043b\\u043e\\u0432\",\"ar\":\"\\u0633\\u0627\\u0631\\u0641\\u0627\\u0631 \\u0643\\u0627\\u0645\\u0648\\u0644\\u0648\\u0641\"}', '{\"en\":\"<p>Their team\'s dedication to quality and attention to detail ensured that our projects were executed flawlessly, exceeding our expectations. Grover\'s seamless integration of construction and logistics services has truly been instrumental in driving our business forward. We are immensely satisfied with the results and highly recommend Grover to anyone seeking a reliable partner for their construction and distribution needs.<\\/p>\",\"ru\":\"<p>\\u041f\\u0440\\u0438\\u0432\\u0435\\u0440\\u0436\\u0435\\u043d\\u043d\\u043e\\u0441\\u0442\\u044c \\u0438\\u0445 \\u043a\\u043e\\u043c\\u0430\\u043d\\u0434\\u044b \\u043a\\u0430\\u0447\\u0435\\u0441\\u0442\\u0432\\u0443 \\u0438 \\u0432\\u043d\\u0438\\u043c\\u0430\\u043d\\u0438\\u0435 \\u043a \\u0434\\u0435\\u0442\\u0430\\u043b\\u044f\\u043c \\u043e\\u0431\\u0435\\u0441\\u043f\\u0435\\u0447\\u0438\\u043b\\u0438 \\u0431\\u0435\\u0437\\u0443\\u043f\\u0440\\u0435\\u0447\\u043d\\u043e\\u0435 \\u0432\\u044b\\u043f\\u043e\\u043b\\u043d\\u0435\\u043d\\u0438\\u0435 \\u043d\\u0430\\u0448\\u0438\\u0445 \\u043f\\u0440\\u043e\\u0435\\u043a\\u0442\\u043e\\u0432, \\u043f\\u0440\\u0435\\u0432\\u0437\\u043e\\u0439\\u0434\\u044f \\u043d\\u0430\\u0448\\u0438 \\u043e\\u0436\\u0438\\u0434\\u0430\\u043d\\u0438\\u044f. \\u0411\\u0435\\u0441\\u043f\\u0440\\u0435\\u043f\\u044f\\u0442\\u0441\\u0442\\u0432\\u0435\\u043d\\u043d\\u0430\\u044f \\u0438\\u043d\\u0442\\u0435\\u0433\\u0440\\u0430\\u0446\\u0438\\u044f \\u0441\\u0442\\u0440\\u043e\\u0438\\u0442\\u0435\\u043b\\u044c\\u043d\\u044b\\u0445 \\u0438 \\u043b\\u043e\\u0433\\u0438\\u0441\\u0442\\u0438\\u0447\\u0435\\u0441\\u043a\\u0438\\u0445 \\u0443\\u0441\\u043b\\u0443\\u0433 Grover \\u0434\\u0435\\u0439\\u0441\\u0442\\u0432\\u0438\\u0442\\u0435\\u043b\\u044c\\u043d\\u043e \\u0441\\u044b\\u0433\\u0440\\u0430\\u043b\\u0430 \\u0432\\u0430\\u0436\\u043d\\u0443\\u044e \\u0440\\u043e\\u043b\\u044c \\u0432 \\u043f\\u0440\\u043e\\u0434\\u0432\\u0438\\u0436\\u0435\\u043d\\u0438\\u0438 \\u043d\\u0430\\u0448\\u0435\\u0433\\u043e \\u0431\\u0438\\u0437\\u043d\\u0435\\u0441\\u0430. \\u041c\\u044b \\u043e\\u0447\\u0435\\u043d\\u044c \\u0434\\u043e\\u0432\\u043e\\u043b\\u044c\\u043d\\u044b \\u0440\\u0435\\u0437\\u0443\\u043b\\u044c\\u0442\\u0430\\u0442\\u0430\\u043c\\u0438 \\u0438 \\u043d\\u0430\\u0441\\u0442\\u043e\\u044f\\u0442\\u0435\\u043b\\u044c\\u043d\\u043e \\u0440\\u0435\\u043a\\u043e\\u043c\\u0435\\u043d\\u0434\\u0443\\u0435\\u043c Grover \\u0432\\u0441\\u0435\\u043c, \\u043a\\u0442\\u043e \\u0438\\u0449\\u0435\\u0442 \\u043d\\u0430\\u0434\\u0435\\u0436\\u043d\\u043e\\u0433\\u043e \\u043f\\u0430\\u0440\\u0442\\u043d\\u0435\\u0440\\u0430 \\u0434\\u043b\\u044f \\u0443\\u0434\\u043e\\u0432\\u043b\\u0435\\u0442\\u0432\\u043e\\u0440\\u0435\\u043d\\u0438\\u044f \\u0441\\u0432\\u043e\\u0438\\u0445 \\u043f\\u043e\\u0442\\u0440\\u0435\\u0431\\u043d\\u043e\\u0441\\u0442\\u0435\\u0439 \\u0432 \\u0441\\u0442\\u0440\\u043e\\u0438\\u0442\\u0435\\u043b\\u044c\\u0441\\u0442\\u0432\\u0435 \\u0438 \\u0441\\u0431\\u044b\\u0442\\u0435.<\\/p>\",\"uz\":\"<p>Ularning jamoasining sifatga sodiqligi va tafsilotlarga e\'tibori bizning loyihalarimiz kutganimizdan ham oshib, benuqson bajarilishini ta\'minladi. Groverning qurilish va logistika xizmatlarini uzluksiz integratsiyasi bizning biznesimizni oldinga siljitishda haqiqatan ham muhim rol o\'ynadi. Biz natijalardan juda mamnunmiz va Groverni qurilish va tarqatish ehtiyojlari uchun ishonchli sherik qidirayotgan har bir kishiga tavsiya qilamiz.<\\/p>\",\"ar\":\"<p>\\u0625\\u0646 \\u062a\\u0641\\u0627\\u0646\\u064a \\u0641\\u0631\\u064a\\u0642\\u0647\\u0645 \\u0641\\u064a \\u0627\\u0644\\u062c\\u0648\\u062f\\u0629 \\u0648\\u0627\\u0644\\u0627\\u0647\\u062a\\u0645\\u0627\\u0645 \\u0628\\u0627\\u0644\\u062a\\u0641\\u0627\\u0635\\u064a\\u0644 \\u064a\\u0636\\u0645\\u0646 \\u062a\\u0646\\u0641\\u064a\\u0630 \\u0645\\u0634\\u0627\\u0631\\u064a\\u0639\\u0646\\u0627 \\u0628\\u0634\\u0643\\u0644 \\u0644\\u0627 \\u062a\\u0634\\u0648\\u0628\\u0647 \\u0634\\u0627\\u0626\\u0628\\u0629\\u060c \\u0628\\u0645\\u0627 \\u064a\\u062a\\u062c\\u0627\\u0648\\u0632 \\u062a\\u0648\\u0642\\u0639\\u0627\\u062a\\u0646\\u0627. \\u0644\\u0642\\u062f \\u0643\\u0627\\u0646 \\u0627\\u0644\\u062a\\u0643\\u0627\\u0645\\u0644 \\u0627\\u0644\\u0633\\u0644\\u0633 \\u0628\\u064a\\u0646 \\u062e\\u062f\\u0645\\u0627\\u062a \\u0627\\u0644\\u0628\\u0646\\u0627\\u0621 \\u0648\\u0627\\u0644\\u062e\\u062f\\u0645\\u0627\\u062a \\u0627\\u0644\\u0644\\u0648\\u062c\\u0633\\u062a\\u064a\\u0629 \\u0645\\u0646 Grover \\u0641\\u0639\\u0627\\u0644\\u0627\\u064b \\u062d\\u0642\\u064b\\u0627 \\u0641\\u064a \\u062f\\u0641\\u0639 \\u0623\\u0639\\u0645\\u0627\\u0644\\u0646\\u0627 \\u0625\\u0644\\u0649 \\u0627\\u0644\\u0623\\u0645\\u0627\\u0645. \\u0646\\u062d\\u0646 \\u0631\\u0627\\u0636\\u0648\\u0646 \\u0644\\u0644\\u063a\\u0627\\u064a\\u0629 \\u0639\\u0646 \\u0627\\u0644\\u0646\\u062a\\u0627\\u0626\\u062c \\u0648\\u0646\\u0648\\u0635\\u064a \\u0628\\u0634\\u062f\\u0629 \\u0628\\u0640 Grover \\u0644\\u0623\\u064a \\u0634\\u062e\\u0635 \\u064a\\u0628\\u062d\\u062b \\u0639\\u0646 \\u0634\\u0631\\u064a\\u0643 \\u0645\\u0648\\u062b\\u0648\\u0642 \\u0644\\u062a\\u0644\\u0628\\u064a\\u0629 \\u0627\\u062d\\u062a\\u064a\\u0627\\u062c\\u0627\\u062a \\u0627\\u0644\\u0628\\u0646\\u0627\\u0621 \\u0648\\u0627\\u0644\\u062a\\u0648\\u0632\\u064a\\u0639 \\u0627\\u0644\\u062e\\u0627\\u0635\\u0629 \\u0628\\u0647.<\\/p>\"}', '2024-03-28 13:13:27', '2024-03-29 10:43:38'),
(11, '{\"en\":\"Hamdam Komilov\",\"uz\":\"Hamdam Komilov\",\"ru\":\"\\u0425\\u0430\\u043c\\u0434\\u0430\\u043c \\u041a\\u043e\\u043c\\u0438\\u043b\\u043e\\u0432\",\"ar\":\"\\u062d\\u0645\\u062f\\u0627\\u0646 \\u0643\\u0648\\u0645\\u064a\\u0644\\u0648\\u0641\"}', '{\"uz\":\"<p>Grover kompaniyamiz uchun ajralmas hamkor bo\'lib, qurilish, tarqatish va import-eksport operatsiyalarimizni aniqlik va tajriba bilan muammosiz boshqaradi. Ularning bizning turli ehtiyojlarimizga yaxlit yondashuvi nafaqat jarayonlarimizni soddalashtirdi, balki xarajatlarimiz va resurslarimizni optimallashtirdi. Eng zamonaviy ob\'ektlarni qurishdan tortib, ta\'minot zanjirimizni samarali boshqarishgacha, Groverning mukammallikka sodiqligi doimiy ravishda ajoyib natijalarni berdi.<\\/p>\",\"en\":\"<p>Grover has been an indispensable partner for our company, seamlessly managing our construction, distribution, and import-export operations with precision and expertise. Their holistic approach to our diverse needs has not only streamlined our processes but also optimized our costs and resources. From constructing state-of-the-art facilities to efficiently managing our supply chain, Grover\'s commitment to excellence has consistently delivered outstanding results.<\\/p>\",\"ru\":\"<p>\\u0413\\u0440\\u043e\\u0432\\u0435\\u0440 \\u0431\\u044b\\u043b \\u043d\\u0435\\u0437\\u0430\\u043c\\u0435\\u043d\\u0438\\u043c\\u044b\\u043c \\u043f\\u0430\\u0440\\u0442\\u043d\\u0435\\u0440\\u043e\\u043c \\u043d\\u0430\\u0448\\u0435\\u0439 \\u043a\\u043e\\u043c\\u043f\\u0430\\u043d\\u0438\\u0438, \\u0447\\u0435\\u0442\\u043a\\u043e \\u0438 \\u043a\\u043e\\u043c\\u043f\\u0435\\u0442\\u0435\\u043d\\u0442\\u043d\\u043e \\u0443\\u043f\\u0440\\u0430\\u0432\\u043b\\u044f\\u044f \\u043d\\u0430\\u0448\\u0438\\u043c\\u0438 \\u043e\\u043f\\u0435\\u0440\\u0430\\u0446\\u0438\\u044f\\u043c\\u0438 \\u043f\\u043e \\u0441\\u0442\\u0440\\u043e\\u0438\\u0442\\u0435\\u043b\\u044c\\u0441\\u0442\\u0432\\u0443, \\u0441\\u0431\\u044b\\u0442\\u0443 \\u0438 \\u0438\\u043c\\u043f\\u043e\\u0440\\u0442\\u0443-\\u044d\\u043a\\u0441\\u043f\\u043e\\u0440\\u0442\\u0443. \\u0418\\u0445 \\u043a\\u043e\\u043c\\u043f\\u043b\\u0435\\u043a\\u0441\\u043d\\u044b\\u0439 \\u043f\\u043e\\u0434\\u0445\\u043e\\u0434 \\u043a \\u043d\\u0430\\u0448\\u0438\\u043c \\u0440\\u0430\\u0437\\u043d\\u043e\\u043e\\u0431\\u0440\\u0430\\u0437\\u043d\\u044b\\u043c \\u043f\\u043e\\u0442\\u0440\\u0435\\u0431\\u043d\\u043e\\u0441\\u0442\\u044f\\u043c \\u043d\\u0435 \\u0442\\u043e\\u043b\\u044c\\u043a\\u043e \\u043e\\u043f\\u0442\\u0438\\u043c\\u0438\\u0437\\u0438\\u0440\\u043e\\u0432\\u0430\\u043b \\u043d\\u0430\\u0448\\u0438 \\u043f\\u0440\\u043e\\u0446\\u0435\\u0441\\u0441\\u044b, \\u043d\\u043e \\u0438 \\u043e\\u043f\\u0442\\u0438\\u043c\\u0438\\u0437\\u0438\\u0440\\u043e\\u0432\\u0430\\u043b \\u043d\\u0430\\u0448\\u0438 \\u0437\\u0430\\u0442\\u0440\\u0430\\u0442\\u044b \\u0438 \\u0440\\u0435\\u0441\\u0443\\u0440\\u0441\\u044b. \\u041e\\u0442 \\u0441\\u0442\\u0440\\u043e\\u0438\\u0442\\u0435\\u043b\\u044c\\u0441\\u0442\\u0432\\u0430 \\u0441\\u043e\\u0432\\u0440\\u0435\\u043c\\u0435\\u043d\\u043d\\u044b\\u0445 \\u043f\\u0440\\u0435\\u0434\\u043f\\u0440\\u0438\\u044f\\u0442\\u0438\\u0439 \\u0434\\u043e \\u044d\\u0444\\u0444\\u0435\\u043a\\u0442\\u0438\\u0432\\u043d\\u043e\\u0433\\u043e \\u0443\\u043f\\u0440\\u0430\\u0432\\u043b\\u0435\\u043d\\u0438\\u044f \\u0446\\u0435\\u043f\\u043e\\u0447\\u043a\\u043e\\u0439 \\u043f\\u043e\\u0441\\u0442\\u0430\\u0432\\u043e\\u043a \\u2014 \\u0441\\u0442\\u0440\\u0435\\u043c\\u043b\\u0435\\u043d\\u0438\\u0435 Grover \\u043a \\u0441\\u043e\\u0432\\u0435\\u0440\\u0448\\u0435\\u043d\\u0441\\u0442\\u0432\\u0443 \\u043d\\u0435\\u0438\\u0437\\u043c\\u0435\\u043d\\u043d\\u043e \\u043f\\u0440\\u0438\\u0432\\u043e\\u0434\\u0438\\u0442 \\u043a \\u0432\\u044b\\u0434\\u0430\\u044e\\u0449\\u0438\\u043c\\u0441\\u044f \\u0440\\u0435\\u0437\\u0443\\u043b\\u044c\\u0442\\u0430\\u0442\\u0430\\u043c.<\\/p>\",\"ar\":\"<p>\\u0644\\u0642\\u062f \\u0643\\u0627\\u0646 Grover \\u0634\\u0631\\u064a\\u0643\\u064b\\u0627 \\u0644\\u0627 \\u063a\\u0646\\u0649 \\u0639\\u0646\\u0647 \\u0644\\u0634\\u0631\\u0643\\u062a\\u0646\\u0627\\u060c \\u062d\\u064a\\u062b \\u0642\\u0627\\u0645 \\u0628\\u0625\\u062f\\u0627\\u0631\\u0629 \\u0639\\u0645\\u0644\\u064a\\u0627\\u062a \\u0627\\u0644\\u0628\\u0646\\u0627\\u0621 \\u0648\\u0627\\u0644\\u062a\\u0648\\u0632\\u064a\\u0639 \\u0648\\u0627\\u0644\\u0627\\u0633\\u062a\\u064a\\u0631\\u0627\\u062f \\u0648\\u0627\\u0644\\u062a\\u0635\\u062f\\u064a\\u0631 \\u0628\\u0633\\u0644\\u0627\\u0633\\u0629 \\u0648\\u0628\\u062f\\u0642\\u0629 \\u0648\\u062e\\u0628\\u0631\\u0629. \\u0625\\u0646 \\u0646\\u0647\\u062c\\u0647\\u0645 \\u0627\\u0644\\u0634\\u0627\\u0645\\u0644 \\u0644\\u062a\\u0644\\u0628\\u064a\\u0629 \\u0627\\u062d\\u062a\\u064a\\u0627\\u062c\\u0627\\u062a\\u0646\\u0627 \\u0627\\u0644\\u0645\\u062a\\u0646\\u0648\\u0639\\u0629 \\u0644\\u0645 \\u064a\\u0624\\u062f\\u064a \\u0625\\u0644\\u0649 \\u062a\\u0628\\u0633\\u064a\\u0637 \\u0639\\u0645\\u0644\\u064a\\u0627\\u062a\\u0646\\u0627 \\u0641\\u062d\\u0633\\u0628\\u060c \\u0628\\u0644 \\u0623\\u062f\\u0649 \\u0623\\u064a\\u0636\\u064b\\u0627 \\u0625\\u0644\\u0649 \\u062a\\u062d\\u0633\\u064a\\u0646 \\u062a\\u0643\\u0627\\u0644\\u064a\\u0641\\u0646\\u0627 \\u0648\\u0645\\u0648\\u0627\\u0631\\u062f\\u0646\\u0627. \\u0628\\u062f\\u0621\\u064b\\u0627 \\u0645\\u0646 \\u0625\\u0646\\u0634\\u0627\\u0621 \\u0623\\u062d\\u062f\\u062b \\u0627\\u0644\\u0645\\u0631\\u0627\\u0641\\u0642 \\u0648\\u0648\\u0635\\u0648\\u0644\\u0627\\u064b \\u0625\\u0644\\u0649 \\u0625\\u062f\\u0627\\u0631\\u0629 \\u0633\\u0644\\u0633\\u0644\\u0629 \\u0627\\u0644\\u062a\\u0648\\u0631\\u064a\\u062f \\u0627\\u0644\\u062e\\u0627\\u0635\\u0629 \\u0628\\u0646\\u0627 \\u0628\\u0643\\u0641\\u0627\\u0621\\u0629\\u060c \\u0623\\u062f\\u0649 \\u0627\\u0644\\u062a\\u0632\\u0627\\u0645 Grover \\u0628\\u0627\\u0644\\u062a\\u0645\\u064a\\u0632 \\u0625\\u0644\\u0649 \\u062a\\u062d\\u0642\\u064a\\u0642 \\u0646\\u062a\\u0627\\u0626\\u062c \\u0631\\u0627\\u0626\\u0639\\u0629 \\u0628\\u0627\\u0633\\u062a\\u0645\\u0631\\u0627\\u0631.<\\/p>\"}', '2024-03-29 10:34:26', '2024-03-29 10:48:06'),
(12, '{\"en\":\"Olim Abidov\",\"ru\":\"\\u041e\\u043b\\u0438\\u043c \\u0410\\u0431\\u0438\\u0434\\u043e\\u0432\",\"uz\":\"Olim Abidov\",\"ar\":\"\\u0623\\u0648\\u0644\\u064a\\u0645 \\u0639\\u0628\\u064a\\u062f\\u0648\\u0641\"}', '{\"en\":\"<p>Their proactive communication, attention to detail, and dedication to meeting deadlines have earned our trust and confidence time and time again. Choosing Grover has been a game-changer for our business, and we wholeheartedly recommend their services to anyone looking for a reliable and innovative partner in the construction and logistics industry.<\\/p>\",\"ru\":\"<p>\\u0418\\u0445 \\u0430\\u043a\\u0442\\u0438\\u0432\\u043d\\u043e\\u0435 \\u043e\\u0431\\u0449\\u0435\\u043d\\u0438\\u0435, \\u0432\\u043d\\u0438\\u043c\\u0430\\u043d\\u0438\\u0435 \\u043a \\u0434\\u0435\\u0442\\u0430\\u043b\\u044f\\u043c \\u0438 \\u043f\\u0440\\u0435\\u0434\\u0430\\u043d\\u043d\\u043e\\u0441\\u0442\\u044c \\u0441\\u043e\\u0431\\u043b\\u044e\\u0434\\u0435\\u043d\\u0438\\u044e \\u0441\\u0440\\u043e\\u043a\\u043e\\u0432 \\u0441\\u043d\\u043e\\u0432\\u0430 \\u0438 \\u0441\\u043d\\u043e\\u0432\\u0430 \\u0437\\u0430\\u0432\\u043e\\u0435\\u0432\\u044b\\u0432\\u0430\\u044e\\u0442 \\u043d\\u0430\\u0448\\u0435 \\u0434\\u043e\\u0432\\u0435\\u0440\\u0438\\u0435. \\u0412\\u044b\\u0431\\u043e\\u0440 Grover \\u0438\\u0437\\u043c\\u0435\\u043d\\u0438\\u043b \\u043f\\u0440\\u0430\\u0432\\u0438\\u043b\\u0430 \\u0438\\u0433\\u0440\\u044b \\u0432 \\u043d\\u0430\\u0448\\u0435\\u043c \\u0431\\u0438\\u0437\\u043d\\u0435\\u0441\\u0435, \\u0438 \\u043c\\u044b \\u0438\\u0441\\u043a\\u0440\\u0435\\u043d\\u043d\\u0435 \\u0440\\u0435\\u043a\\u043e\\u043c\\u0435\\u043d\\u0434\\u0443\\u0435\\u043c \\u0438\\u0445 \\u0443\\u0441\\u043b\\u0443\\u0433\\u0438 \\u0432\\u0441\\u0435\\u043c, \\u043a\\u0442\\u043e \\u0438\\u0449\\u0435\\u0442 \\u043d\\u0430\\u0434\\u0435\\u0436\\u043d\\u043e\\u0433\\u043e \\u0438 \\u0438\\u043d\\u043d\\u043e\\u0432\\u0430\\u0446\\u0438\\u043e\\u043d\\u043d\\u043e\\u0433\\u043e \\u043f\\u0430\\u0440\\u0442\\u043d\\u0435\\u0440\\u0430 \\u0432 \\u0441\\u0444\\u0435\\u0440\\u0435 \\u0441\\u0442\\u0440\\u043e\\u0438\\u0442\\u0435\\u043b\\u044c\\u0441\\u0442\\u0432\\u0430 \\u0438 \\u043b\\u043e\\u0433\\u0438\\u0441\\u0442\\u0438\\u043a\\u0438.<\\/p>\",\"uz\":\"<p>Ularning faol muloqoti, tafsilotlarga e\'tibor berish va belgilangan muddatlarga rioya qilish bizning ishonchimiz va ishonchimizni qayta-qayta qozongan. Grover-ni tanlash bizning biznesimiz uchun o\'yinni o\'zgartirdi va biz qurilish va logistika sohasida ishonchli va innovatsion sherik izlayotgan har bir kishiga ularning xizmatlarini chin dildan tavsiya qilamiz.<\\/p>\",\"ar\":\"<p>\\u0625\\u0646 \\u062a\\u0648\\u0627\\u0635\\u0644\\u0647\\u0645 \\u0627\\u0644\\u0627\\u0633\\u062a\\u0628\\u0627\\u0642\\u064a \\u0648\\u0627\\u0647\\u062a\\u0645\\u0627\\u0645\\u0647\\u0645 \\u0628\\u0627\\u0644\\u062a\\u0641\\u0627\\u0635\\u064a\\u0644 \\u0648\\u062a\\u0641\\u0627\\u0646\\u064a\\u0647\\u0645 \\u0641\\u064a \\u0627\\u0644\\u0648\\u0641\\u0627\\u0621 \\u0628\\u0627\\u0644\\u0645\\u0648\\u0627\\u0639\\u064a\\u062f \\u0627\\u0644\\u0646\\u0647\\u0627\\u0626\\u064a\\u0629 \\u0642\\u062f \\u0623\\u0643\\u0633\\u0628\\u0646\\u0627 \\u062b\\u0642\\u062a\\u0646\\u0627 \\u0645\\u0631\\u0627\\u0631\\u064b\\u0627 \\u0648\\u062a\\u0643\\u0631\\u0627\\u0631\\u064b\\u0627. \\u0644\\u0642\\u062f \\u0623\\u062f\\u0649 \\u0627\\u062e\\u062a\\u064a\\u0627\\u0631 Grover \\u0625\\u0644\\u0649 \\u062a\\u063a\\u064a\\u064a\\u0631 \\u0642\\u0648\\u0627\\u0639\\u062f \\u0627\\u0644\\u0644\\u0639\\u0628\\u0629 \\u0641\\u064a \\u0623\\u0639\\u0645\\u0627\\u0644\\u0646\\u0627\\u060c \\u0648\\u0646\\u062d\\u0646 \\u0646\\u0648\\u0635\\u064a \\u0628\\u0634\\u062f\\u0629 \\u0628\\u062e\\u062f\\u0645\\u0627\\u062a\\u0647\\u0627 \\u0644\\u0623\\u064a \\u0634\\u062e\\u0635 \\u064a\\u0628\\u062d\\u062b \\u0639\\u0646 \\u0634\\u0631\\u064a\\u0643 \\u0645\\u0648\\u062b\\u0648\\u0642 \\u0648\\u0645\\u0628\\u062a\\u0643\\u0631 \\u0641\\u064a \\u0635\\u0646\\u0627\\u0639\\u0629 \\u0627\\u0644\\u0628\\u0646\\u0627\\u0621 \\u0648\\u0627\\u0644\\u062e\\u062f\\u0645\\u0627\\u062a \\u0627\\u0644\\u0644\\u0648\\u062c\\u0633\\u062a\\u064a\\u0629.<\\/p>\"}', '2024-03-29 10:49:49', '2024-03-29 10:50:39');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vacations`
--

CREATE TABLE `vacations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `location` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `vacations`
--

INSERT INTO `vacations` (`id`, `title`, `location`, `description`, `created_at`, `updated_at`) VALUES
(1, '{\"en\":\"Assistant Manager\",\"ru\":\"\\u0410\\u0441\\u0441\\u0438\\u0441\\u0442\\u0435\\u043d\\u0442 \\u043c\\u0435\\u043d\\u0435\\u0434\\u0436\\u0435\\u0440\\u0430\",\"uz\":\"Menejer yordamchisi\",\"ar\":\"\\u0645\\u0633\\u0627\\u0639\\u062f \\u0645\\u062f\\u064a\\u0631\"}', '{\"en\":\"Tashkent\",\"ru\":\"\\u0422\\u0430\\u0448\\u043a\\u0435\\u043d\\u0442\",\"uz\":\"Toshkent\",\"ar\":\"\\u0637\\u0634\\u0642\\u0646\\u062f\"}', '{\"en\":\"<p>Working conditions<\\/p><ul style=\\\"list-style-type:disc;\\\"><li style=\\\"list-style-type:disc;\\\">Full-time position with flexible working hours;<\\/li><li style=\\\"list-style-type:disc;\\\">Competitive salary commensurate with experience;<\\/li><li style=\\\"list-style-type:disc;\\\">Generous vacation and sick leave policy;<\\/li><li style=\\\"list-style-type:disc;\\\">Collaborative team-oriented work environment.<\\/li><\\/ul><p>Requirements for candidates<\\/p><ul style=\\\"list-style-type:disc;\\\"><li style=\\\"list-style-type:disc;\\\">Law degree from an accredited institution;<\\/li><li style=\\\"list-style-type:disc;\\\">2+ years of experience in litigation, corporate law or a related field;<\\/li><li style=\\\"list-style-type:disc;\\\">Excellent communication and analytical skills;<\\/li><li style=\\\"list-style-type:disc;\\\">Ability to manage multiple priorities and deadlines.<\\/li><\\/ul><p>Salary<\\/p><ul style=\\\"list-style-type:disc;\\\"><li style=\\\"list-style-type:disc;\\\"><span style=\\\"color:hsl(0, 75%, 60%);\\\">1,200$<\\/span> for firth 3 month, after it decreases <span style=\\\"color:hsl(0, 75%, 60%);\\\">+10%<\\/span> every 3 month for <span style=\\\"color:hsl(0, 75%, 60%);\\\">2 years<\\/span>.<\\/li><\\/ul>\",\"ru\":\"<p>\\u0420\\u0430\\u0431\\u043e\\u0447\\u0438\\u0435 \\u0443\\u0441\\u043b\\u043e\\u0432\\u0438\\u044f<br>\\u041f\\u043e\\u043b\\u043d\\u0430\\u044f \\u0437\\u0430\\u043d\\u044f\\u0442\\u043e\\u0441\\u0442\\u044c \\u0441 \\u0433\\u0438\\u0431\\u043a\\u0438\\u043c \\u0433\\u0440\\u0430\\u0444\\u0438\\u043a\\u043e\\u043c \\u0440\\u0430\\u0431\\u043e\\u0442\\u044b;<br>\\u041a\\u043e\\u043d\\u043a\\u0443\\u0440\\u0435\\u043d\\u0442\\u043d\\u0430\\u044f \\u0437\\u0430\\u0440\\u0430\\u0431\\u043e\\u0442\\u043d\\u0430\\u044f \\u043f\\u043b\\u0430\\u0442\\u0430, \\u0441\\u043e\\u043e\\u0442\\u0432\\u0435\\u0442\\u0441\\u0442\\u0432\\u0443\\u044e\\u0449\\u0430\\u044f \\u043e\\u043f\\u044b\\u0442\\u0443 \\u0440\\u0430\\u0431\\u043e\\u0442\\u044b;<br>\\u0429\\u0435\\u0434\\u0440\\u0430\\u044f \\u043f\\u043e\\u043b\\u0438\\u0442\\u0438\\u043a\\u0430 \\u043e\\u0442\\u043f\\u0443\\u0441\\u043a\\u043e\\u0432 \\u0438 \\u0431\\u043e\\u043b\\u044c\\u043d\\u0438\\u0447\\u043d\\u044b\\u0445;<br>\\u0420\\u0430\\u0431\\u043e\\u0447\\u0430\\u044f \\u0430\\u0442\\u043c\\u043e\\u0441\\u0444\\u0435\\u0440\\u0430, \\u043e\\u0440\\u0438\\u0435\\u043d\\u0442\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u043d\\u0430\\u044f \\u043d\\u0430 \\u0441\\u043e\\u0432\\u043c\\u0435\\u0441\\u0442\\u043d\\u0443\\u044e \\u0440\\u0430\\u0431\\u043e\\u0442\\u0443 \\u0432 \\u043a\\u043e\\u043c\\u0430\\u043d\\u0434\\u0435.<br>\\u0422\\u0440\\u0435\\u0431\\u043e\\u0432\\u0430\\u043d\\u0438\\u044f \\u043a \\u043a\\u0430\\u043d\\u0434\\u0438\\u0434\\u0430\\u0442\\u0430\\u043c<br>\\u042e\\u0440\\u0438\\u0434\\u0438\\u0447\\u0435\\u0441\\u043a\\u043e\\u0435 \\u043e\\u0431\\u0440\\u0430\\u0437\\u043e\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043a\\u043a\\u0440\\u0435\\u0434\\u0438\\u0442\\u043e\\u0432\\u0430\\u043d\\u043d\\u043e\\u0433\\u043e \\u0443\\u0447\\u0440\\u0435\\u0436\\u0434\\u0435\\u043d\\u0438\\u044f;<br>\\u041e\\u043f\\u044b\\u0442 \\u0440\\u0430\\u0431\\u043e\\u0442\\u044b \\u043e\\u0442 2 \\u043b\\u0435\\u0442 \\u0432 \\u0441\\u0443\\u0434\\u0435\\u0431\\u043d\\u044b\\u0445 \\u0434\\u0435\\u043b\\u0430\\u0445, \\u043a\\u043e\\u0440\\u043f\\u043e\\u0440\\u0430\\u0442\\u0438\\u0432\\u043d\\u043e\\u043c \\u043f\\u0440\\u0430\\u0432\\u0435 \\u0438\\u043b\\u0438 \\u0441\\u043c\\u0435\\u0436\\u043d\\u044b\\u0445 \\u043e\\u0431\\u043b\\u0430\\u0441\\u0442\\u044f\\u0445;<br>\\u041e\\u0442\\u043b\\u0438\\u0447\\u043d\\u044b\\u0435 \\u043a\\u043e\\u043c\\u043c\\u0443\\u043d\\u0438\\u043a\\u0430\\u0442\\u0438\\u0432\\u043d\\u044b\\u0435 \\u0438 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0442\\u0438\\u0447\\u0435\\u0441\\u043a\\u0438\\u0435 \\u0441\\u043f\\u043e\\u0441\\u043e\\u0431\\u043d\\u043e\\u0441\\u0442\\u0438;<br>\\u0423\\u043c\\u0435\\u043d\\u0438\\u0435 \\u0443\\u043f\\u0440\\u0430\\u0432\\u043b\\u044f\\u0442\\u044c \\u043d\\u0435\\u0441\\u043a\\u043e\\u043b\\u044c\\u043a\\u0438\\u043c\\u0438 \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442\\u0430\\u043c\\u0438 \\u0438 \\u0441\\u0440\\u043e\\u043a\\u0430\\u043c\\u0438.<br>\\u0417\\u0430\\u0440\\u043f\\u043b\\u0430\\u0442\\u0430<br><span style=\\\"color:hsl(0,75%,60%);\\\">1200$ <\\/span>\\u0437\\u0430 \\u043f\\u0435\\u0440\\u0432\\u044b\\u0435 3 \\u043c\\u0435\\u0441\\u044f\\u0446\\u0430, \\u0434\\u0430\\u043b\\u0435\\u0435 \\u0441\\u043d\\u0438\\u0436\\u0430\\u0435\\u0442\\u0441\\u044f <span style=\\\"color:hsl(0,75%,60%);\\\">+10%<\\/span> \\u043a\\u0430\\u0436\\u0434\\u044b\\u0435 3 \\u043c\\u0435\\u0441\\u044f\\u0446\\u0430 \\u0432 \\u0442\\u0435\\u0447\\u0435\\u043d\\u0438\\u0435 <span style=\\\"color:hsl(0,75%,60%);\\\">2<\\/span> <span style=\\\"color:hsl(0, 75%, 60%);\\\">\\u043b\\u0435\\u0442<\\/span>.<\\/p>\",\"ar\":\"<p>\\u0638\\u0631\\u0648\\u0641 \\u0627\\u0644\\u0639\\u0645\\u0644<br>\\u062f\\u0648\\u0627\\u0645 \\u0643\\u0627\\u0645\\u0644 \\u0645\\u0639 \\u062c\\u062f\\u0648\\u0644 \\u0639\\u0645\\u0644 \\u0645\\u0631\\u0646\\u061b<br>\\u0631\\u0627\\u062a\\u0628 \\u062a\\u0646\\u0627\\u0641\\u0633\\u064a \\u064a\\u062a\\u0646\\u0627\\u0633\\u0628 \\u0645\\u0639 \\u0627\\u0644\\u062e\\u0628\\u0631\\u0629\\u061b<br>\\u0633\\u064a\\u0627\\u0633\\u0629 \\u0627\\u0644\\u0625\\u062c\\u0627\\u0632\\u0627\\u062a \\u0648\\u0627\\u0644\\u0625\\u062c\\u0627\\u0632\\u0627\\u062a \\u0627\\u0644\\u0645\\u0631\\u0636\\u064a\\u0629 \\u0627\\u0644\\u0633\\u062e\\u064a\\u0629\\u061b<br>\\u0628\\u064a\\u0626\\u0629 \\u0639\\u0645\\u0644 \\u0645\\u0648\\u062c\\u0647\\u0629 \\u0646\\u062d\\u0648 \\u0627\\u0644\\u0641\\u0631\\u064a\\u0642.<br>\\u0645\\u062a\\u0637\\u0644\\u0628\\u0627\\u062a \\u0627\\u0644\\u0645\\u0631\\u0634\\u062d\\u064a\\u0646<br>\\u0627\\u0644\\u062a\\u0639\\u0644\\u064a\\u0645 \\u0627\\u0644\\u0642\\u0627\\u0646\\u0648\\u0646\\u064a \\u0645\\u0646 \\u0645\\u0624\\u0633\\u0633\\u0629 \\u0645\\u0639\\u062a\\u0645\\u062f\\u0629\\u061b<br>\\u0633\\u0646\\u062a\\u064a\\u0646 \\u0645\\u0646 \\u0627\\u0644\\u062e\\u0628\\u0631\\u0629 \\u0641\\u064a \\u0627\\u0644\\u062f\\u0639\\u0627\\u0648\\u0649 \\u0627\\u0644\\u0642\\u0636\\u0627\\u0626\\u064a\\u0629 \\u0623\\u0648 \\u0642\\u0627\\u0646\\u0648\\u0646 \\u0627\\u0644\\u0634\\u0631\\u0643\\u0627\\u062a \\u0623\\u0648 \\u0627\\u0644\\u0645\\u062c\\u0627\\u0644\\u0627\\u062a \\u0630\\u0627\\u062a \\u0627\\u0644\\u0635\\u0644\\u0629\\u061b<br>\\u0645\\u0647\\u0627\\u0631\\u0627\\u062a \\u062a\\u0648\\u0627\\u0635\\u0644 \\u0648\\u062a\\u062d\\u0644\\u064a\\u0644\\u064a\\u0629 \\u0645\\u0645\\u062a\\u0627\\u0632\\u0629\\u061b<br>\\u0627\\u0644\\u0642\\u062f\\u0631\\u0629 \\u0639\\u0644\\u0649 \\u0625\\u062f\\u0627\\u0631\\u0629 \\u0627\\u0644\\u0623\\u0648\\u0644\\u0648\\u064a\\u0627\\u062a \\u0648\\u0627\\u0644\\u0645\\u0648\\u0627\\u0639\\u064a\\u062f \\u0627\\u0644\\u0646\\u0647\\u0627\\u0626\\u064a\\u0629 \\u0627\\u0644\\u0645\\u062a\\u0639\\u062f\\u062f\\u0629.<br>\\u0645\\u0631\\u062a\\u0628<br><span style=\\\"color:hsl(0, 75%, 60%);\\\">1200<\\/span> \\u062f\\u0648\\u0644\\u0627\\u0631 \\u0644\\u0623\\u0648\\u0644 3 \\u0623\\u0634\\u0647\\u0631\\u060c \\u062b\\u0645 \\u064a\\u062a\\u0645 \\u062a\\u062e\\u0641\\u064a\\u0636\\u0647\\u0627 \\u0628\\u0646\\u0633\\u0628\\u0629 <span style=\\\"color:hsl(0, 75%, 60%);\\\">+10%<\\/span> \\u0643\\u0644 3 \\u0623\\u0634\\u0647\\u0631 \\u0644\\u0645\\u062f\\u0629 \\u0639\\u0627\\u0645\\u064a\\u0646.<\\/p>\",\"uz\":\"<p>Ish sharoitlari<br>Moslashuvchan ish jadvali bilan to\'liq ish vaqti;<br>Tajribaga mos keladigan raqobatbardosh ish haqi;<br>Saxiy ta\'til va kasallik ta\'tillari siyosati;<br>Jamoaga yo\'naltirilgan ish muhiti.<br>Nomzodlarga qo\'yiladigan talablar<br>Akkreditatsiya qilingan muassasada yuridik ta\'lim;<br>Sud ishlari, korporativ huquq yoki tegishli sohalarda 2 yillik tajriba;<br>Zo\'r muloqot va analitik qobiliyat;<br>Bir nechta ustuvorliklar va muddatlarni boshqarish qobiliyati.<br>Ish haqi<br>Dastlabki 3 oy uchun <span style=\\\"color:hsl(0, 75%, 60%);\\\">$1200<\\/span>, keyin <span style=\\\"color:hsl(0, 75%, 60%);\\\">2 yil<\\/span> davomida har 3 oyda <span style=\\\"color:hsl(0, 75%, 60%);\\\">+10%<\\/span> ga kamayadi.<\\/p>\"}', '2024-03-28 13:13:27', '2024-03-29 10:05:31'),
(2, '{\"en\":\"UI\\/UX designer\",\"ar\":\"\\u0645\\u0635\\u0645\\u0645 \\u0648\\u0627\\u062c\\u0647\\u0629 \\u0627\\u0644\\u0645\\u0633\\u062a\\u062e\\u062f\\u0645\\/UX\",\"ru\":\"UI\\/UX \\u0434\\u0438\\u0437\\u0430\\u0439\\u043d\\u0435\\u0440\",\"uz\":\"UI\\/UX dizayner\"}', '{\"en\":\"Remote\",\"ru\":\"\\u0423\\u0434\\u0430\\u043b\\u0435\\u043d\\u043d\\u043e\",\"ar\":\"\\u0628\\u0639\\u064a\\u062f\",\"uz\":\"Masofaviy\"}', '{\"en\":\"<p>Working conditions<\\/p><ul style=\\\"list-style-type:disc;\\\"><li style=\\\"list-style-type:disc;\\\">Full-time position with flexible working hours;<\\/li><li style=\\\"list-style-type:disc;\\\">Competitive salary commensurate with experience;<\\/li><li style=\\\"list-style-type:disc;\\\">Generous vacation and sick leave policy;<\\/li><li style=\\\"list-style-type:disc;\\\">Collaborative team-oriented work environment.<\\/li><\\/ul><p>Requirements for candidates<\\/p><ul style=\\\"list-style-type:disc;\\\"><li style=\\\"list-style-type:disc;\\\">Law degree from an accredited institution;<\\/li><li style=\\\"list-style-type:disc;\\\">2+ years of experience in litigation, corporate law or a related field;<\\/li><li style=\\\"list-style-type:disc;\\\">Excellent communication and analytical skills;<\\/li><li style=\\\"list-style-type:disc;\\\">Ability to manage multiple priorities and deadlines.<\\/li><\\/ul><p>Salary<\\/p><ul style=\\\"list-style-type:disc;\\\"><li style=\\\"list-style-type:disc;\\\"><span style=\\\"color:hsl(0, 75%, 60%);\\\">1,200$<\\/span> for firth 3 month, after it decreases <span style=\\\"color:hsl(0, 75%, 60%);\\\">+10%<\\/span> every 3 month for <span style=\\\"color:hsl(0, 75%, 60%);\\\">2 years<\\/span>.<\\/li><\\/ul>\",\"ru\":\"<p>\\u0420\\u0430\\u0431\\u043e\\u0447\\u0438\\u0435 \\u0443\\u0441\\u043b\\u043e\\u0432\\u0438\\u044f<br>\\u041f\\u043e\\u043b\\u043d\\u0430\\u044f \\u0437\\u0430\\u043d\\u044f\\u0442\\u043e\\u0441\\u0442\\u044c \\u0441 \\u0433\\u0438\\u0431\\u043a\\u0438\\u043c \\u0433\\u0440\\u0430\\u0444\\u0438\\u043a\\u043e\\u043c \\u0440\\u0430\\u0431\\u043e\\u0442\\u044b;<br>\\u041a\\u043e\\u043d\\u043a\\u0443\\u0440\\u0435\\u043d\\u0442\\u043d\\u0430\\u044f \\u0437\\u0430\\u0440\\u0430\\u0431\\u043e\\u0442\\u043d\\u0430\\u044f \\u043f\\u043b\\u0430\\u0442\\u0430, \\u0441\\u043e\\u043e\\u0442\\u0432\\u0435\\u0442\\u0441\\u0442\\u0432\\u0443\\u044e\\u0449\\u0430\\u044f \\u043e\\u043f\\u044b\\u0442\\u0443 \\u0440\\u0430\\u0431\\u043e\\u0442\\u044b;<br>\\u0429\\u0435\\u0434\\u0440\\u0430\\u044f \\u043f\\u043e\\u043b\\u0438\\u0442\\u0438\\u043a\\u0430 \\u043e\\u0442\\u043f\\u0443\\u0441\\u043a\\u043e\\u0432 \\u0438 \\u0431\\u043e\\u043b\\u044c\\u043d\\u0438\\u0447\\u043d\\u044b\\u0445;<br>\\u0420\\u0430\\u0431\\u043e\\u0447\\u0430\\u044f \\u0430\\u0442\\u043c\\u043e\\u0441\\u0444\\u0435\\u0440\\u0430, \\u043e\\u0440\\u0438\\u0435\\u043d\\u0442\\u0438\\u0440\\u043e\\u0432\\u0430\\u043d\\u043d\\u0430\\u044f \\u043d\\u0430 \\u0441\\u043e\\u0432\\u043c\\u0435\\u0441\\u0442\\u043d\\u0443\\u044e \\u0440\\u0430\\u0431\\u043e\\u0442\\u0443 \\u0432 \\u043a\\u043e\\u043c\\u0430\\u043d\\u0434\\u0435.<br>\\u0422\\u0440\\u0435\\u0431\\u043e\\u0432\\u0430\\u043d\\u0438\\u044f \\u043a \\u043a\\u0430\\u043d\\u0434\\u0438\\u0434\\u0430\\u0442\\u0430\\u043c<br>\\u042e\\u0440\\u0438\\u0434\\u0438\\u0447\\u0435\\u0441\\u043a\\u043e\\u0435 \\u043e\\u0431\\u0440\\u0430\\u0437\\u043e\\u0432\\u0430\\u043d\\u0438\\u0435 \\u0430\\u043a\\u043a\\u0440\\u0435\\u0434\\u0438\\u0442\\u043e\\u0432\\u0430\\u043d\\u043d\\u043e\\u0433\\u043e \\u0443\\u0447\\u0440\\u0435\\u0436\\u0434\\u0435\\u043d\\u0438\\u044f;<br>\\u041e\\u043f\\u044b\\u0442 \\u0440\\u0430\\u0431\\u043e\\u0442\\u044b \\u043e\\u0442 2 \\u043b\\u0435\\u0442 \\u0432 \\u0441\\u0443\\u0434\\u0435\\u0431\\u043d\\u044b\\u0445 \\u0434\\u0435\\u043b\\u0430\\u0445, \\u043a\\u043e\\u0440\\u043f\\u043e\\u0440\\u0430\\u0442\\u0438\\u0432\\u043d\\u043e\\u043c \\u043f\\u0440\\u0430\\u0432\\u0435 \\u0438\\u043b\\u0438 \\u0441\\u043c\\u0435\\u0436\\u043d\\u044b\\u0445 \\u043e\\u0431\\u043b\\u0430\\u0441\\u0442\\u044f\\u0445;<br>\\u041e\\u0442\\u043b\\u0438\\u0447\\u043d\\u044b\\u0435 \\u043a\\u043e\\u043c\\u043c\\u0443\\u043d\\u0438\\u043a\\u0430\\u0442\\u0438\\u0432\\u043d\\u044b\\u0435 \\u0438 \\u0430\\u043d\\u0430\\u043b\\u0438\\u0442\\u0438\\u0447\\u0435\\u0441\\u043a\\u0438\\u0435 \\u0441\\u043f\\u043e\\u0441\\u043e\\u0431\\u043d\\u043e\\u0441\\u0442\\u0438;<br>\\u0423\\u043c\\u0435\\u043d\\u0438\\u0435 \\u0443\\u043f\\u0440\\u0430\\u0432\\u043b\\u044f\\u0442\\u044c \\u043d\\u0435\\u0441\\u043a\\u043e\\u043b\\u044c\\u043a\\u0438\\u043c\\u0438 \\u043f\\u0440\\u0438\\u043e\\u0440\\u0438\\u0442\\u0435\\u0442\\u0430\\u043c\\u0438 \\u0438 \\u0441\\u0440\\u043e\\u043a\\u0430\\u043c\\u0438.<br>\\u0417\\u0430\\u0440\\u043f\\u043b\\u0430\\u0442\\u0430<br><span style=\\\"color:hsl(0,75%,60%);\\\">1200$ <\\/span>\\u0437\\u0430 \\u043f\\u0435\\u0440\\u0432\\u044b\\u0435 3 \\u043c\\u0435\\u0441\\u044f\\u0446\\u0430, \\u0434\\u0430\\u043b\\u0435\\u0435 \\u0441\\u043d\\u0438\\u0436\\u0430\\u0435\\u0442\\u0441\\u044f <span style=\\\"color:hsl(0,75%,60%);\\\">+10%<\\/span> \\u043a\\u0430\\u0436\\u0434\\u044b\\u0435 3 \\u043c\\u0435\\u0441\\u044f\\u0446\\u0430 \\u0432 \\u0442\\u0435\\u0447\\u0435\\u043d\\u0438\\u0435 <span style=\\\"color:hsl(0,75%,60%);\\\">2<\\/span> <span style=\\\"color:hsl(0,75%,60%);\\\">\\u043b\\u0435\\u0442<\\/span>.<\\/p>\",\"ar\":\"<p>\\u0638\\u0631\\u0648\\u0641 \\u0627\\u0644\\u0639\\u0645\\u0644<br>\\u062f\\u0648\\u0627\\u0645 \\u0643\\u0627\\u0645\\u0644 \\u0645\\u0639 \\u062c\\u062f\\u0648\\u0644 \\u0639\\u0645\\u0644 \\u0645\\u0631\\u0646\\u061b<br>\\u0631\\u0627\\u062a\\u0628 \\u062a\\u0646\\u0627\\u0641\\u0633\\u064a \\u064a\\u062a\\u0646\\u0627\\u0633\\u0628 \\u0645\\u0639 \\u0627\\u0644\\u062e\\u0628\\u0631\\u0629\\u061b<br>\\u0633\\u064a\\u0627\\u0633\\u0629 \\u0627\\u0644\\u0625\\u062c\\u0627\\u0632\\u0627\\u062a \\u0648\\u0627\\u0644\\u0625\\u062c\\u0627\\u0632\\u0627\\u062a \\u0627\\u0644\\u0645\\u0631\\u0636\\u064a\\u0629 \\u0627\\u0644\\u0633\\u062e\\u064a\\u0629\\u061b<br>\\u0628\\u064a\\u0626\\u0629 \\u0639\\u0645\\u0644 \\u0645\\u0648\\u062c\\u0647\\u0629 \\u0646\\u062d\\u0648 \\u0627\\u0644\\u0641\\u0631\\u064a\\u0642.<br>\\u0645\\u062a\\u0637\\u0644\\u0628\\u0627\\u062a \\u0627\\u0644\\u0645\\u0631\\u0634\\u062d\\u064a\\u0646<br>\\u0627\\u0644\\u062a\\u0639\\u0644\\u064a\\u0645 \\u0627\\u0644\\u0642\\u0627\\u0646\\u0648\\u0646\\u064a \\u0645\\u0646 \\u0645\\u0624\\u0633\\u0633\\u0629 \\u0645\\u0639\\u062a\\u0645\\u062f\\u0629\\u061b<br>\\u0633\\u0646\\u062a\\u064a\\u0646 \\u0645\\u0646 \\u0627\\u0644\\u062e\\u0628\\u0631\\u0629 \\u0641\\u064a \\u0627\\u0644\\u062f\\u0639\\u0627\\u0648\\u0649 \\u0627\\u0644\\u0642\\u0636\\u0627\\u0626\\u064a\\u0629 \\u0623\\u0648 \\u0642\\u0627\\u0646\\u0648\\u0646 \\u0627\\u0644\\u0634\\u0631\\u0643\\u0627\\u062a \\u0623\\u0648 \\u0627\\u0644\\u0645\\u062c\\u0627\\u0644\\u0627\\u062a \\u0630\\u0627\\u062a \\u0627\\u0644\\u0635\\u0644\\u0629\\u061b<br>\\u0645\\u0647\\u0627\\u0631\\u0627\\u062a \\u062a\\u0648\\u0627\\u0635\\u0644 \\u0648\\u062a\\u062d\\u0644\\u064a\\u0644\\u064a\\u0629 \\u0645\\u0645\\u062a\\u0627\\u0632\\u0629\\u061b<br>\\u0627\\u0644\\u0642\\u062f\\u0631\\u0629 \\u0639\\u0644\\u0649 \\u0625\\u062f\\u0627\\u0631\\u0629 \\u0627\\u0644\\u0623\\u0648\\u0644\\u0648\\u064a\\u0627\\u062a \\u0648\\u0627\\u0644\\u0645\\u0648\\u0627\\u0639\\u064a\\u062f \\u0627\\u0644\\u0646\\u0647\\u0627\\u0626\\u064a\\u0629 \\u0627\\u0644\\u0645\\u062a\\u0639\\u062f\\u062f\\u0629.<br>\\u0645\\u0631\\u062a\\u0628<br><span style=\\\"color:hsl(0,75%,60%);\\\">1200<\\/span> \\u062f\\u0648\\u0644\\u0627\\u0631 \\u0644\\u0623\\u0648\\u0644 3 \\u0623\\u0634\\u0647\\u0631\\u060c \\u062b\\u0645 \\u064a\\u062a\\u0645 \\u062a\\u062e\\u0641\\u064a\\u0636\\u0647\\u0627 \\u0628\\u0646\\u0633\\u0628\\u0629 <span style=\\\"color:hsl(0,75%,60%);\\\">+10%<\\/span> \\u0643\\u0644 3 \\u0623\\u0634\\u0647\\u0631 \\u0644\\u0645\\u062f\\u0629 \\u0639\\u0627\\u0645\\u064a\\u0646.<\\/p>\",\"uz\":\"<ul><li>Ish sharoitlari<br>Moslashuvchan ish jadvali bilan to\'liq ish vaqti;<br>Tajribaga mos keladigan raqobatbardosh ish haqi;<br>Saxiy ta\'til va kasallik ta\'tillari siyosati;<br>Jamoaga yo\'naltirilgan ish muhiti.<br>Nomzodlarga qo\'yiladigan talablar<br>Akkreditatsiya qilingan muassasada yuridik ta\'lim;<br>Sud ishlari, korporativ huquq yoki tegishli sohalarda 2 yillik tajriba;<br>Zo\'r muloqot va analitik qobiliyat;<br>Bir nechta ustuvorliklar va muddatlarni boshqarish qobiliyati.<br>Ish haqi<br>Dastlabki 3 oy uchun <span style=\\\"color:hsl(0,75%,60%);\\\">$1200<\\/span>, keyin <span style=\\\"color:hsl(0,75%,60%);\\\">2 yil<\\/span> davomida har 3 oyda <span style=\\\"color:hsl(0,75%,60%);\\\">+10%<\\/span> ga kamayadi.<\\/li><\\/ul>\"}', '2024-03-28 13:13:27', '2024-03-29 10:06:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `moonshine_change_logs`
--
ALTER TABLE `moonshine_change_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `moonshine_change_logs_changelogable_type_changelogable_id_index` (`changelogable_type`,`changelogable_id`);

--
-- Indexes for table `moonshine_socialites`
--
ALTER TABLE `moonshine_socialites`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `moonshine_socialites_driver_identity_unique` (`driver`,`identity`);

--
-- Indexes for table `moonshine_users`
--
ALTER TABLE `moonshine_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `moonshine_users_email_unique` (`email`),
  ADD KEY `moonshine_users_moonshine_user_role_id_foreign` (`moonshine_user_role_id`);

--
-- Indexes for table `moonshine_user_permissions`
--
ALTER TABLE `moonshine_user_permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `moonshine_user_roles`
--
ALTER TABLE `moonshine_user_roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `photos`
--
ALTER TABLE `photos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `photos_project_id_foreign` (`project_id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `vacations`
--
ALTER TABLE `vacations`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `moonshine_change_logs`
--
ALTER TABLE `moonshine_change_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `moonshine_socialites`
--
ALTER TABLE `moonshine_socialites`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `moonshine_users`
--
ALTER TABLE `moonshine_users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `moonshine_user_permissions`
--
ALTER TABLE `moonshine_user_permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `moonshine_user_roles`
--
ALTER TABLE `moonshine_user_roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `photos`
--
ALTER TABLE `photos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vacations`
--
ALTER TABLE `vacations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `moonshine_users`
--
ALTER TABLE `moonshine_users`
  ADD CONSTRAINT `moonshine_users_moonshine_user_role_id_foreign` FOREIGN KEY (`moonshine_user_role_id`) REFERENCES `moonshine_user_roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `photos`
--
ALTER TABLE `photos`
  ADD CONSTRAINT `photos_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
